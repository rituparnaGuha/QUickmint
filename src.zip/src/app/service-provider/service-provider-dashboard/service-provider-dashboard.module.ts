import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ServiceProviderDashboardRoutingModule } from './service-provider-dashboard-routing.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ServiceProviderDashboardRoutingModule
  ]
})
export class ServiceProviderDashboardModule { }
