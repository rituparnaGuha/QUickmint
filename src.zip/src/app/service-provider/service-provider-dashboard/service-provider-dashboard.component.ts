import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-provider-dashboard',
  templateUrl: './service-provider-dashboard.component.html',
  styleUrls: ['./service-provider-dashboard.component.css']
})
export class ServiceProviderDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
