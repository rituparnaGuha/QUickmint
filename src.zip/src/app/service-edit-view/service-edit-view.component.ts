import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-edit-view',
  templateUrl: './service-edit-view.component.html',
  styleUrls: ['./service-edit-view.component.css']
})
export class ServiceEditViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
