import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-provider-wallet-history',
  templateUrl: './provider-wallet-history.component.html',
  styleUrls: ['./provider-wallet-history.component.css']
})
export class ProviderWalletHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
