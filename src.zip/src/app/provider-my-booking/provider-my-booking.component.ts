import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-provider-my-booking',
  templateUrl: './provider-my-booking.component.html',
  styleUrls: ['./provider-my-booking.component.css']
})
export class ProviderMyBookingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
