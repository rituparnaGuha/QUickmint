import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-provider-my-transactions',
  templateUrl: './provider-my-transactions.component.html',
  styleUrls: ['./provider-my-transactions.component.css']
})
export class ProviderMyTransactionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
