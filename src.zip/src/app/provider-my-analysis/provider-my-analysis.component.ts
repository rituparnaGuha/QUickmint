import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-provider-my-analysis',
  templateUrl: './provider-my-analysis.component.html',
  styleUrls: ['./provider-my-analysis.component.css']
})
export class ProviderMyAnalysisComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
