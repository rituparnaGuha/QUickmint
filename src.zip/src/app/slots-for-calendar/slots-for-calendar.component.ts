import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slots-for-calendar',
  templateUrl: './slots-for-calendar.component.html',
  styleUrls: ['./slots-for-calendar.component.css']
})
export class SlotsForCalendarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
