import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { ClassDetailsPopupComponent } from '../class-details-popup/class-details-popup.component';
import { JitsiComponent } from '../jitsi/jitsi.component';
import { WebserviceService } from '../services/webservice.service';

@Component({
  selector: 'app-register-class-list',
  templateUrl: './register-class-list.component.html',
  styleUrls: ['./register-class-list.component.css'],
})
export class RegisterClassListComponent implements OnInit {
  userType = localStorage.getItem('userType');
  id = localStorage.getItem('userId');
  userData = JSON.parse(localStorage.getItem('userData')!);

  classesList: any;
  providersList: any;
  data: any;
  constructor(
    public service: WebserviceService,
    public dialog: MatDialog,
    public toast: ToastrService
  ) {}

  ngOnInit(): void {
    this.userType == '1' ? this.getMyClasses() : this.getAllClassesList();
  }

  getMyClasses() {
    this.service.getClassesListProvider(this.id).subscribe((resp: any) => {
      console.log('getMyClasses: ', resp);
      this.classesList = resp.data;
    });
  }

  getAllClassesList() {
    this.service.getClassesList().subscribe((resp: any) => {
      console.log('getAllClassesList: ', resp);
      this.classesList = resp.data;
    });
  }

  displayExpertise(c: any) {
    // console.log("c",  c)
    let exp = '';
    for (let [i, expertise] of c.expertise.entries()) {
      i == c.expertise.length - 1
        ? (exp += expertise)
        : (exp += expertise + ', ');
    }
    return exp;
  }

  doaction(c: any) {
    if (this.id === c.provider_id) {
      return this.joinMeeting(c);
    } else {
      for (let student of c.booked_students) {
        if (this.id! == student.Student_id) {
          return this.joinMeeting(c);
        }
      }
      return this.registerForClass(c);
    }
  }

  joinMeeting(c: any) {
    const dialogRef = this.dialog.open(JitsiComponent, {
      // width: '250px',
      data: {
        provider: { _id: c.provider_id },
        user: { _id: c._id },
      },
    });
  }

  registerForClass(c: any) {
    let data = {
      Student_id: this.id,
      Student_email: this.userData.UserEmail,
      Student_name: this.userData.UserFullName,
    };
    this.service.bookClass(c._id, data).subscribe((resp: any) => {
      console.log('registerForClass: ', resp);

      if (resp.success) {
        this.toast.success('Registered successfully!');
        this.getAllClassesList();
      }
    });
  }

  setButtonText(c: any) {
    if (this.id === c.provider_id) {
      return 'Join Meeting';
    } else {
      for (let student of c.booked_students) {
        if (this.id! == student.Student_id) {
          return 'Join Meeting';
        }
      }
      return 'Register for class';
    }
  }
  onValueChanged(ev: any) {
    console.log('from prov list: ', ev);
    this.data.lowerPrice = ev.price;
    this.data.minAge = ev.minAge;
    this.data.maxAge = ev.maxAge;
    console.log('data: ', this.data);

    this.getProviders(this.data);
  }

  getProviders(data: any) {
    let latlng = localStorage.getItem('userData')!;

    let d = JSON.parse(latlng).UserLocation;
    console.log('data: ', data);
    // console.log(latlng)
    // console.log(d)
    let queryParams = {
      category_id: data.category_id._id,
      sub_category_id: data._id,
      Latitude: d.Latitude,
      Longitude: d.Longitude,
      url: '',
      lowerPrice: data.lowerPrice,
      minAge: data.minAge,
      maxAge: data.maxAge,
    };
    this.service.getProvidersList(queryParams).subscribe((data: any) => {
      this.providersList = data.data;
      console.log('providersList: ', data.data);
    });
  }

  openDialog(job: any): void {
    const dialogRef = this.dialog.open(ClassDetailsPopupComponent, {
      // width: '250px',
      data: {
        job,
      },
    });
  }
}
