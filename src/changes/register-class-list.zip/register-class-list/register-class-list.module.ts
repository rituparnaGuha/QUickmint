import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RegisterClassListRoutingModule } from './register-class-list-routing.module';
import { RegisterClassListComponent } from './register-class-list.component';
import { FilterModule } from '../component/filter/filter.module';

@NgModule({
  declarations: [RegisterClassListComponent],
  imports: [CommonModule, RegisterClassListRoutingModule, FilterModule],
})
export class RegisterClassListModule {}
